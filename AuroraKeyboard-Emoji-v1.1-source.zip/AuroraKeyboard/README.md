# Aurora AI Keyboard — native Android source (v0.1 alpha)

A functional, offline-first custom Android input method, aimed at Galaxy S26 Ultra but not yet tested on that device. Kotlin / Android InputMethodService, min Android 8, target API 35.

## Build
Open this folder with Android Studio, install Android SDK 35 and Gradle 8.9+ (Android Studio can provide Gradle). Sync and build `app` / Build APK. This archive does not include an APK or Gradle wrapper binaries. Gradle 8.9 is compatible with the configured Android Gradle plugin 8.7.3.

## Enable
Install the resulting APK, open Aurora AI Keyboard, tap Enable, then Select. Android displays a keyboard security warning for **all** third-party keyboards. Check the permissions and only enable software you trust.

## Implemented in source
- Always-present number row, standard letter rows, shift/backspace, punctuation and symbols, enter, space.
- On-device frequency-based personal word learning, up to 2,500 tokens; 3 prefix predictions; starter English and Spanish vocabulary; globe-key language toggle (manual, **not automatic language detection**).
- Multicolor, Light, AMOLED, Ocean and adjustable custom key color themes.
- Explicit-save clipboard history, paste, pin/unpin, clear; unpinned clips expire after 24 hours; 30-item limit. Clipboard history is **not encrypted**: Android private app storage only. Do not save secrets.
- Password input disables suggestion/learning and clipboard capture; incognito disables learning and clipboard saves; no internet permission, app backup disabled.

## Known limitations / before everyday use
This is an **untested alpha source project**, not a production-quality SwiftKey replacement. No swipe typing, polished autocorrect, true next-word model, multi-word phrase learning, learned bigrams, automatic language recognition, voice or generative AI. Predictions match word prefixes only. Key layout, accessibility, landscape, tablet, emoji, selection and complex scripts require testing and improvements. Changes in Settings to themes apply on keyboard recreation. Clipboard viewing is available in sensitive fields but saves are disabled; avoid using clipboard for secrets. Some password-like fields fail to mark themselves correctly; do not promise universal sensitive-field detection. Word statistics and clipboard records are plain-text private preferences; use encrypted storage before storing sensitive content. The keyboard's own settings activity is a standard Android page.

No data is transmitted. Review source carefully before installing any custom keyboard.

## v0.5 Backspace behavior
Tap Backspace to delete once (including autocorrect undo). Hold 380 ms for continuous character deletion. Repeat speeds up after 12 deletions and stops on release, cancellation, input finish or view rebuild. Unicode code points are deleted correctly.
