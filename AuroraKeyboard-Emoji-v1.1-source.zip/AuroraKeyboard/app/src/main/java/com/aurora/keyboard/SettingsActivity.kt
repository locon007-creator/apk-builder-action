package com.aurora.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
 private lateinit var store: Store
 private lateinit var content: LinearLayout
 private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
 private val ink = 0xffe9f1ff.toInt()
 private val muted = 0xffa9b9d0.toInt()
 private fun shape(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = radius.dp.toFloat() }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); store = Store(this); render() }
 private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
  text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
 }
 private fun section(name: String, subtitle: String, block: LinearLayout.() -> Unit) {
  content.addView(text(name, 19f, ink, true).apply { setPadding(2.dp, 22.dp, 0, 3.dp) })
  content.addView(text(subtitle, 12f, muted).apply { setPadding(2.dp, 0, 0, 10.dp) })
  val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14.dp, 11.dp, 14.dp, 11.dp); background = shape(0xff192b43.toInt()); block() }
  content.addView(card, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 10.dp })
 }
 private fun LinearLayout.line(title: String, subtitle: String, action: () -> Unit) {
  val item = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(8.dp, 12.dp, 8.dp, 12.dp); background = shape(0xff233955.toInt(), 12); setOnClickListener { action() } }
  item.addView(text(title + "  ›", 15f, ink, true)); item.addView(text(subtitle, 12f, muted))
  addView(item, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 8.dp })
 }
 private fun LinearLayout.switch(title: String, subtitle: String, checked: Boolean, change: (Boolean) -> Unit) {
  val row = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4.dp, 12.dp, 4.dp, 12.dp) }
  val copy = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.VERTICAL; addView(text(title, 15f, ink, true)); addView(text(subtitle, 12f, muted)) }
  row.addView(copy, LinearLayout.LayoutParams(0,-2,1f))
  row.addView(Switch(this@SettingsActivity).apply { isChecked = checked; setOnCheckedChangeListener { _, active -> change(active) } })
  addView(row)
 }
 private fun options(title: String, options: List<String>, selected: String, update: (String) -> Unit) {
  val index = options.indexOf(selected).coerceAtLeast(0)
  AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options.toTypedArray(), index) { dialog, which -> update(options[which]); dialog.dismiss(); render() }.setNegativeButton("Cancel", null).show()
 }
 private fun render() {
  content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20.dp, 20.dp, 20.dp, 32.dp); setBackgroundColor(0xff0d192b.toInt()) }
  val scroll = ScrollView(this).apply { fillViewport = true; addView(content) }; setContentView(scroll)
  content.addView(text("AURORA  /  KEYBOARD", 12f, 0xff73b7ff.toInt(), true))
  content.addView(text("Your typing, your way.", 29f, ink, true).apply { setPadding(0, 6.dp, 0, 3.dp) })
  content.addView(text("A calmer setup, quicker controls, and private on-device learning.", 13f, muted))
  section("Get started", "Two steps to use Aurora anywhere") {
   line("Enable keyboard", "Open Android keyboard settings") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
   line("Choose Aurora", "Set it as your current keyboard") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
  }
  section("Appearance", "Personalize the typing surface") {
   line("Keyboard theme · ${store.theme()}", "Multicolor, Light, AMOLED, Ocean or Custom") { options("Choose a theme", listOf("Multicolor","Light","AMOLED","Ocean","Custom"), store.theme(), store::setTheme) }
   line("Custom key color", "Current: ${String.format("#%06X", store.customColor() and 0xffffff)}") {
    val field = EditText(this@SettingsActivity).apply { setSingleLine(true); setText(String.format("#%06X", store.customColor() and 0xffffff)); setSelectAllOnFocus(true) }
    AlertDialog.Builder(this@SettingsActivity).setTitle("Custom color").setView(field).setPositiveButton("Apply") { _, _ ->
     try { store.setCustomColor(Color.parseColor(field.text.toString())); store.setTheme("Custom"); render() }
     catch (_: IllegalArgumentException) { Toast.makeText(this@SettingsActivity, "Use a color such as #344C78", Toast.LENGTH_SHORT).show() }
    }.setNegativeButton("Cancel", null).show()
   }
  }
  section("Typing feel", "Comfortable feedback with each press") {
   line("Vibration · ${store.hapticStrength()}", "Respects Android's system haptic switch") { options("Key vibration", listOf("Off","Light","Standard","Strong"), store.hapticStrength(), store::setHapticStrength) }
   switch("Keypress sounds", "Soft audible feedback", store.keySounds(), store::setKeySounds)
  }
  section("Smart typing", "Predict and correct on your device") {
   switch("Word predictions & learning", "Remember frequently used words", store.learning(), store::setLearning)
   switch("Autocorrect on space", "Backspace once to restore your word", store.autocorrect(), store::setAutocorrect)
   switch("English + Español", "Show suggestions from both languages", store.bilingual(), store::setBilingual)
  }
  section("Privacy & clipboard", "Control exactly what Aurora stores") {
   switch("Incognito mode", "Pause learning and clipboard saves", store.incognito(), store::setIncognito)
   line("Clear learned words", "Remove word frequencies and next-word history") {
    AlertDialog.Builder(this@SettingsActivity).setTitle("Delete all learned words?").setPositiveButton("Delete") { _, _ -> store.clearWords(); Toast.makeText(this@SettingsActivity,"Vocabulary cleared",Toast.LENGTH_SHORT).show() }.setNegativeButton("Cancel", null).show()
   }
   line("Clear clipboard history", "Remove saved and pinned clips") {
    AlertDialog.Builder(this@SettingsActivity).setTitle("Delete all saved clips?").setPositiveButton("Delete") { _, _ -> store.clearClips(); Toast.makeText(this@SettingsActivity,"Clipboard cleared",Toast.LENGTH_SHORT).show() }.setNegativeButton("Cancel", null).show()
   }
  }
  content.addView(text("OFFLINE BY DESIGN  •  No internet permission. Passwords are never learned. Clipboard entries are saved only when requested; unpinned entries expire after 24 hours.", 11f, muted).apply { setPadding(4.dp, 18.dp, 4.dp, 0) })
 }
}
