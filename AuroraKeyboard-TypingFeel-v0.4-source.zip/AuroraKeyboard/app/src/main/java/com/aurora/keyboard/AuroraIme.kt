package com.aurora.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AuroraIme : InputMethodService() {
 private lateinit var store: Store
 private lateinit var root: LinearLayout
 private lateinit var suggestions: LinearLayout
 private var composing = StringBuilder()
 private var previousWord = ""
 private var undoCorrection: Pair<String, String>? = null
 private var shift = false
 private var symbols = false
 private var moreSymbols = false
 private var spanish = false
 private var sensitive = false
 private var fieldLearningAllowed = true
 private val english = "the and you are for that with this have from your hello thanks please good morning today tomorrow minutes work can will there what when where yes no time send message later meeting home phone keyboard".split(" ")
 private val espanol = "hola gracias buenos días buenas tardes mañana hoy para como que con estoy estar tienes puedo enviar mensaje tiempo trabajo casa teléfono teclado mañana luego por favor cuando donde sí no".split(" ")
 override fun onCreate() { super.onCreate(); store = Store(this) }
 override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
  super.onStartInput(attribute, restarting)
  composing.clear(); previousWord = ""; undoCorrection = null
  val variation = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
  val klass = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
  sensitive = variation in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD, InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) || klass == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
  fieldLearningAllowed = !sensitive && variation != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_URI
 }
 override fun onCreateInputView(): View {
  root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(2.dp, 5.dp, 2.dp, 7.dp) }
  render(); return root
 }
 private fun palette(): Pair<Int, Int> = when(store.theme()) {
  "Light" -> Color.rgb(232,237,247) to Color.rgb(255,255,255)
  "AMOLED" -> Color.BLACK to Color.rgb(31,35,43)
  "Ocean" -> Color.rgb(7,39,57) to Color.rgb(23,87,112)
  "Custom" -> Color.rgb(12,20,32) to store.customColor()
  else -> Color.rgb(12,22,38) to Color.rgb(34,65,104)
 }
 private fun keyColor(i: Int): Int {
  if (store.theme() != "Multicolor") return palette().second
  return intArrayOf(0xff164b99.toInt(), 0xff28458d.toInt(), 0xff224f68.toInt(), 0xff573479.toInt(), 0xff643363.toInt())[i % 5]
 }
 private fun bg(color: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = 15.dp.toFloat() }
 private fun feedback(button: Button) {
  val strength = store.hapticStrength()
  if (strength != "Off" && android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 1) {
   val duration = when (strength) { "Light" -> 7L; "Strong" -> 22L; else -> 13L }
   val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
   if (vibrator?.hasVibrator() == true) vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
   else button.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
  }
  if (store.keySounds()) (getSystemService(Context.AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEY_CLICK, 0.35f)
 }
 private fun key(text: String, weight: Float = 1f, color: Int = keyColor(text.hashCode().ushr(1)), action: () -> Unit): Button = Button(this).apply {
  this.text = if (text == "space") "English • Español" else text; textSize = if (text.length > 6) 11f else if (text.length > 2) 14f else 21f; isAllCaps = false
  setTextColor(if (store.theme() == "Light") Color.BLACK else Color.WHITE)
  setPadding(0,0,0,0); minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
  background = RippleDrawable(ColorStateList.valueOf(0x66ffffff), bg(color), null); layoutParams = LinearLayout.LayoutParams(0, 49.dp, weight).apply { setMargins(2.dp,3.dp,2.dp,3.dp) }
  setOnClickListener { feedback(this); action() }
 }
 private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
 private fun row(keys: List<String>, weights: List<Float>? = null, inset: Int = 0) {
  val line = LinearLayout(this).apply {
   orientation = LinearLayout.HORIZONTAL
   setPadding(inset.dp, 0, inset.dp, 0)
  }
  keys.forEachIndexed { i, label ->
   val special = label in listOf("⇧", "⌫", "?123", "ABC", "#+=", "123", "🌐", "↵")
   val color = when {
    label == "↵" -> 0xff3779ec.toInt()
    special -> if (store.theme() == "Light") 0xffc3d0e1.toInt() else 0xff3b4b64.toInt()
    else -> keyColor(i)
   }
   line.addView(key(label, weights?.get(i) ?: 1f, color) { press(label) })
  }
  root.addView(line)
 }
 private fun render() {
  if (!::root.isInitialized) return
  root.removeAllViews(); root.setBackgroundColor(palette().first)
  suggestions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
  root.addView(suggestions, LinearLayout.LayoutParams(-1, 46.dp))
  updateSuggestions()
  row((1..9).map { it.toString() } + "0")
  if (symbols) {
   if (moreSymbols) {
    row("~ ` | • √ π ÷ × ¶ ∆".split(" "))
    row(listOf("£", "€", "¥", "^", "°", "=", "{", "}", "\\", "©"))
   } else {
    row("@ # $ % & - + ( ) /".split(" "))
    row(listOf("*", "\"", ":", ";", "!", "?", "'", "_", "="))
   }
   row(listOf("#+=", "<", ">", "[", "]", "⌫"), listOf(1.5f, 1f, 1f, 1f, 1f, 1.5f))
  } else {
   row("qwertyuiop".map { it.toString() })
   row("asdfghjkl".map { it.toString() }, inset = 18)
   row(listOf("⇧") + "zxcvbnm".map { it.toString() } + "⌫", listOf(1.45f) + List(7) { 1f } + 1.45f)
  }
  row(listOf(if (symbols) "ABC" else "?123", "🌐", ",", "space", ".", "↵"), listOf(1.3f, .8f, .7f, 4.2f, .7f, 1.3f))
 }
 private fun updateSuggestions() {
  if (!::suggestions.isInitialized) return
  suggestions.removeAllViews()
  val clipboard = key("▤", .54f, 0xff1c3656.toInt()) { if (!sensitive) showClipboard() }
  suggestions.addView(clipboard)
  val prefix = composing.toString().lowercase(Locale.ROOT)
  val dict = ((if (store.bilingual()) english + espanol else if (spanish) espanol else english) + store.wordMap().keys).distinct()
  val frequencies = store.wordMap()
  val predictions = when {
   sensitive -> listOf("", "Private field", "")
   prefix.isBlank() -> store.nextWords(previousWord).entries.sortedByDescending { it.value }.map { it.key }.take(3).ifEmpty { listOf("", if(spanish) "Español" else "English", "") }
   else -> dict.asSequence().filter { it.startsWith(prefix) && it != prefix }.sortedWith(compareByDescending<String> { store.nextWords(previousWord)[it] ?: 0 }.thenByDescending { frequencies[it] ?: 0 }).take(3).toList().ifEmpty { listOf(prefix) }
  }
  predictions.forEach { option -> suggestions.addView(key(option, 1f, 0xff203551.toInt()) {
   if (!sensitive && option.isNotBlank()) {
    if (prefix.isNotBlank()) currentInputConnection?.deleteSurroundingText(composing.length, 0)
    currentInputConnection?.commitText(if (prefix.isBlank()) "$option " else "$option ", 1)
    if (fieldLearningAllowed) { store.learn(option); store.learnPair(previousWord, option) }
    previousWord = option.lowercase(Locale.ROOT)
    undoCorrection = null; composing.clear(); updateSuggestions()
   }
  }) }
  suggestions.addView(key("⚙", .54f, 0xff1c3656.toInt()) { startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) })
 }
 private fun commitWord(allowCorrection: Boolean = false) {
  val original = composing.toString()
  if (original.isBlank()) return
  val dict = (english + espanol + store.wordMap().keys).distinct()
  val corrected = if (allowCorrection && store.autocorrect() && !sensitive && !store.incognito() && original.length >= 3 && dict.none { it.equals(original, true) }) {
   dict.asSequence().filter { it.length in (original.length - 1)..(original.length + 1) }
    .map { it to editDistance(original.lowercase(Locale.ROOT), it.lowercase(Locale.ROOT)) }
    .filter { it.second == 1 }.sortedByDescending { store.wordMap()[it.first.lowercase(Locale.ROOT)] ?: 0 }.firstOrNull()?.first ?: original
  } else original
  if (corrected != original) {
   currentInputConnection?.deleteSurroundingText(original.length, 0)
   currentInputConnection?.commitText(corrected, 1)
   undoCorrection = original to corrected
  } else undoCorrection = null
  if (fieldLearningAllowed) { store.learn(corrected); store.learnPair(previousWord, corrected) }
  previousWord = corrected.lowercase(Locale.ROOT)
  composing.clear()
 }
 private fun editDistance(a: String, b: String): Int {
  if (kotlin.math.abs(a.length - b.length) > 1) return 2
  val distance = IntArray(b.length + 1) { it }
  for (i in a.indices) {
   var previous = distance[0]; distance[0] = i + 1
   for (j in b.indices) {
    val before = distance[j+1]
    distance[j+1] = minOf(distance[j+1] + 1, distance[j] + 1, previous + if(a[i] == b[j]) 0 else 1)
    previous = before
   }
  }
  return distance[b.length]
 }
 private fun press(label: String) {
  val ic = currentInputConnection ?: return
  when(label) {
   "⇧" -> { shift = !shift; render() }
   "⌫" -> {
    val undo = undoCorrection
    if (undo != null && composing.isEmpty() && ic.getTextBeforeCursor(undo.second.length + 1, 0)?.toString()?.endsWith(undo.second + " ") == true) {
     ic.deleteSurroundingText(undo.second.length + 1, 0); ic.commitText(undo.first, 1)
     composing.append(undo.first); undoCorrection = null
    } else {
     undoCorrection = null
     if (composing.isNotEmpty()) composing.deleteCharAt(composing.lastIndex)
     ic.deleteSurroundingText(1,0)
    }
    updateSuggestions()
   }
   "space" -> { commitWord(true); ic.commitText(" ",1); updateSuggestions() }
   "↵" -> { commitWord(); if (!ic.performEditorAction(currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE)) ic.commitText("\n",1); updateSuggestions() }
   "🌐" -> { commitWord(); spanish = !spanish; render() }
   "?123", "ABC", "123" -> { symbols = !symbols; moreSymbols = false; render() }
   "#+=" -> { moreSymbols = !moreSymbols; render() }
   else -> {
    val value = if (shift) label.uppercase(Locale.ROOT) else label
    ic.commitText(value,1)
    if (label.length == 1 && (label[0].isLetter() || label == "'")) { composing.append(value); undoCorrection = null }
    else commitWord()
    shift = false; updateSuggestions()
   }
  }
 }
 private fun showClipboard() {
  val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); setBackgroundColor(palette().first) }
  panel.addView(key("← Back to keyboard") { render() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  panel.addView(key("Save current clipboard (explicit)") {
   if (!sensitive && !store.incognito()) manager.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.let { store.saveClip(it) }
   showClipboard()
  }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  if (sensitive) { render(); return }
  store.clips().forEach { clip ->
   val line = LinearLayout(this)
   line.addView(key(clip.text.take(32).replace("\n", " "), 4f) { currentInputConnection?.commitText(clip.text,1); render() })
   line.addView(key(if(clip.pinned) "★" else "☆") { store.pinClip(clip.text); showClipboard() })
   panel.addView(line)
  }
  panel.addView(key("Clear clipboard history") { store.clearClips(); showClipboard() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  root.removeAllViews(); root.addView(panel)
 }
}
