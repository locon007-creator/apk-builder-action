package com.aurora.keyboard

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Stores word frequencies, not full typed messages. No network access. */
class Store(context: Context) {
 private val prefs: SharedPreferences = context.getSharedPreferences("aurora_local", Context.MODE_PRIVATE)
 fun theme(): String = prefs.getString("theme", "Graphite") ?: "Graphite"
 fun setTheme(theme: String) { prefs.edit().putString("theme", theme).apply() }
 fun customColor(): Int = prefs.getInt("customColor", 0xff344c78.toInt())
 fun setCustomColor(color: Int) { prefs.edit().putInt("customColor", color).apply() }
 fun hapticStrength(): String = prefs.getString("haptic_strength", "Standard") ?: "Standard"
 fun setHapticStrength(value: String) { prefs.edit().putString("haptic_strength", value).apply() }
 fun keySounds(): Boolean = prefs.getBoolean("key_sounds", false)
 fun setKeySounds(value: Boolean) { prefs.edit().putBoolean("key_sounds", value).apply() }
 fun learning(): Boolean = prefs.getBoolean("learning", true)
 fun setLearning(value: Boolean) { prefs.edit().putBoolean("learning", value).apply() }
 fun incognito(): Boolean = prefs.getBoolean("incognito", false)
 fun setIncognito(value: Boolean) { prefs.edit().putBoolean("incognito", value).apply() }
 fun wordMap(): MutableMap<String, Int> {
  val json = JSONObject(prefs.getString("words", "{}") ?: "{}")
  return json.keys().asSequence().associateWith { json.optInt(it, 0) }.toMutableMap()
 }
 fun learn(word: String) {
  if (!learning() || incognito()) return
  val clean = word.trim().lowercase(Locale.ROOT)
  if (clean.length !in 2..32 || !clean.all { it.isLetter() || it == '\'' || it == 'ñ' }) return
  val words = wordMap()
  words[clean] = (words[clean] ?: 0).coerceAtMost(10000) + 1
  if (words.size > 2500) words.entries.minByOrNull { it.value }?.let { words.remove(it.key) }
  prefs.edit().putString("words", JSONObject(words as Map<*, *>).toString()).apply()
 }
 fun autocorrect(): Boolean = prefs.getBoolean("autocorrect", false)
 fun setAutocorrect(value: Boolean) { prefs.edit().putBoolean("autocorrect", value).apply() }
 fun bilingual(): Boolean = prefs.getBoolean("bilingual", true)
 fun setBilingual(value: Boolean) { prefs.edit().putBoolean("bilingual", value).apply() }
 fun nextWords(previous: String): Map<String, Int> {
  val key = previous.lowercase(Locale.ROOT).trim()
  val data = JSONObject(prefs.getString("next_words", "{}") ?: "{}")
  val candidates = data.optJSONObject(key) ?: return emptyMap()
  return candidates.keys().asSequence().associateWith { candidates.optInt(it) }
 }
 fun learnPair(previous: String, next: String) {
  if (!learning() || incognito()) return
  val a = previous.lowercase(Locale.ROOT).trim()
  val b = next.lowercase(Locale.ROOT).trim()
  if (a.length !in 2..32 || b.length !in 2..32 || !a.all { it.isLetter() || it == '\'' } || !b.all { it.isLetter() || it == '\'' }) return
  val all = JSONObject(prefs.getString("next_words", "{}") ?: "{}")
  val entries = all.optJSONObject(a) ?: JSONObject()
  entries.put(b, (entries.optInt(b) + 1).coerceAtMost(10000))
  if (entries.length() > 25) {
   val least = entries.keys().asSequence().minByOrNull { entries.optInt(it) }
   if (least != null) entries.remove(least)
  }
  all.put(a, entries)
  if (all.length() > 600) {
   val oldest = all.keys().asSequence().firstOrNull()
   if (oldest != null) all.remove(oldest)
  }
  prefs.edit().putString("next_words", all.toString()).apply()
 }
 fun clearWords() { prefs.edit().remove("words").remove("next_words").apply() }
 data class Clip(val text: String, val pinned: Boolean, val time: Long)
 fun clips(): List<Clip> {
  val arr = JSONArray(prefs.getString("clips", "[]") ?: "[]")
  val now = System.currentTimeMillis()
  return (0 until arr.length()).mapNotNull { index ->
   val o = arr.optJSONObject(index) ?: return@mapNotNull null
   val clip = Clip(o.optString("text"), o.optBoolean("pinned"), o.optLong("time"))
   clip.takeIf { it.pinned || now - it.time < 86_400_000L }
  }
 }
 fun saveClip(text: String) {
  if (incognito() || text.isBlank()) return
  writeClips((listOf(Clip(text.take(1000), false, System.currentTimeMillis())) + clips().filter { it.text != text }).take(30))
 }
 fun pinClip(text: String) { writeClips(clips().map { if (it.text == text) it.copy(pinned = !it.pinned) else it }) }
 fun removeClip(text: String) { writeClips(clips().filterNot { it.text == text }) }
 fun clearClips() { prefs.edit().remove("clips").apply() }
 private fun writeClips(clips: List<Clip>) {
  val arr = JSONArray()
  clips.forEach { arr.put(JSONObject().put("text", it.text).put("pinned", it.pinned).put("time", it.time)) }
  prefs.edit().putString("clips", arr.toString()).apply()
 }
}
