package com.aurora.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.InsetDrawable
import android.content.res.ColorStateList
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Handler
import android.os.Looper
import android.view.ViewConfiguration
import android.view.MotionEvent
import android.view.HapticFeedbackConstants
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AuroraIme : InputMethodService() {
 private lateinit var store: Store
 private lateinit var root: LinearLayout
 private lateinit var suggestions: LinearLayout
 private var composing = StringBuilder()
 private var previousWord = ""
 private var undoCorrection: Pair<String, String>? = null
 private var shift = false
 private var symbols = false
 private var moreSymbols = false
 private var spanish = false
 private var sensitive = false
 private var fieldLearningAllowed = true
 private val backspaceHandler = Handler(Looper.getMainLooper())
 private val suggestionHandler = Handler(Looper.getMainLooper())
 private var pendingSuggestions: Runnable? = null
 private val predictionButtons = mutableListOf<Button>()
 private var predictionVocabulary: List<String>? = null
 private var predictionFrequencies: Map<String, Int>? = null
 private var predictionNext: Map<String, Int>? = null
 private fun invalidatePredictions() { predictionVocabulary = null; predictionFrequencies = null; predictionNext = null }
 private fun scheduleSuggestions() {
  pendingSuggestions?.let { suggestionHandler.removeCallbacks(it) }
  val work = Runnable { pendingSuggestions = null; updateSuggestions() }
  pendingSuggestions = work
  suggestionHandler.postDelayed(work, 35L)
 }
 private fun cancelSuggestions() { pendingSuggestions?.let { suggestionHandler.removeCallbacks(it) }; pendingSuggestions = null }
 private var backspaceRepeater: Runnable? = null
 private var backspaceLongPressed = false
 private var backspaceRepeats = 0
 private val english = "the and you are for that with this have from your hello thanks please good morning today tomorrow minutes work can will there what when where yes no time send message later meeting home phone keyboard".split(" ")
 private val espanol = "hola gracias buenos días buenas tardes mañana hoy para como que con estoy estar tienes puedo enviar mensaje tiempo trabajo casa teléfono teclado mañana luego por favor cuando donde sí no".split(" ")
 override fun onCreate() { super.onCreate(); store = Store(this) }
 override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
  stopBackspaceRepeat()
  super.onStartInput(attribute, restarting)
  cancelSuggestions(); invalidatePredictions()
  composing.clear(); previousWord = ""; undoCorrection = null
  val variation = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
  val klass = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
  sensitive = variation in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD, InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) || klass == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
  fieldLearningAllowed = !sensitive && variation != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_URI
 }
 override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
  super.onStartInputView(info, restarting)
  if (::root.isInitialized) render()
 }
 override fun onCreateInputView(): View {
  root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(2.dp, 3.dp, 2.dp, 5.dp) }
  render(); return root
 }
 private fun palette(): Pair<Int, Int> = when(store.theme()) {
  "Light" -> 0xffe4e9ef.toInt() to Color.WHITE
  "AMOLED" -> Color.BLACK to 0xff202127.toInt()
  "Ocean" -> 0xff082c42.toInt() to 0xff21627f.toInt()
  "Midnight" -> 0xff101827.toInt() to 0xff26344b.toInt()
  "Graphite" -> 0xff262930.toInt() to 0xff454a54.toInt()
  "Rose" -> 0xff382337.toInt() to 0xff774766.toInt()
  "Sunset" -> 0xff39243c.toInt() to 0xffb04a62.toInt()
  "Lavender" -> 0xff26203e.toInt() to 0xff6c5a9c.toInt()
  "Mint" -> 0xff123b38.toInt() to 0xff2d8372.toInt()
  "Custom" -> 0xff101827.toInt() to store.customColor()
  else -> 0xff0c1626.toInt() to 0xff224168.toInt()
 }
 private fun keyColor(i: Int): Int {
  if (store.theme() != "Multicolor") return palette().second
  return intArrayOf(0xff164b99.toInt(), 0xff28458d.toInt(), 0xff224f68.toInt(), 0xff573479.toInt(), 0xff643363.toInt())[i % 5]
 }
 private fun bg(color: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = 7.dp.toFloat() }
 private fun feedback(button: Button) {
  val strength = store.hapticStrength()
  if (strength != "Off" && android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 1) {
   val duration = when (strength) { "Light" -> 7L; "Strong" -> 22L; else -> 13L }
   val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
   if (vibrator?.hasVibrator() == true) vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
   else button.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
  }
  if (store.keySounds()) (getSystemService(Context.AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEY_CLICK, 0.35f)
 }
 private fun key(text: String, weight: Float = 1f, color: Int = keyColor(text.hashCode().ushr(1)), action: () -> Unit): Button = Button(this).apply {
  this.text = if (text == "space") (if (spanish) "Español" else "English (US)") else text; textSize = if (text == "space") 13f else if (text.length > 6) 11f else if (text.length > 2) 14f else 20f; isAllCaps = false
  setTextColor(if (store.theme() == "Light") Color.BLACK else Color.WHITE)
  // Never let narrow number keys or suggestions break into two lines.
  setSingleLine(true); maxLines = 1; includeFontPadding = false
  ellipsize = android.text.TextUtils.TruncateAt.END
  setAutoSizeTextTypeUniformWithConfiguration(10, 20, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
  setPadding(0,0,0,0); minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
  // Keep the entire weighted cell touchable; inset only the painted key, not its hit box.
  // Previously 2dp horizontal + 4dp vertical margins created dead zones between keys.
  background = RippleDrawable(ColorStateList.valueOf(0x33ffffff), InsetDrawable(bg(color), 1.dp, 2.dp, 1.dp, 2.dp), null)
  elevation = 1.dp.toFloat()
  layoutParams = LinearLayout.LayoutParams(0, 57.dp, weight)
  if (text.length == 1 && text[0].isLetter()) {
   val alternatives = mapOf("a" to "áàâäãå", "e" to "éèêë", "i" to "íìîï", "o" to "óòôöõ", "u" to "úùûü", "n" to "ñ", "c" to "ç")
   alternatives[text]?.let { choices -> setOnLongClickListener {
    val values = choices.map { it.toString() }.toTypedArray()
    android.app.AlertDialog.Builder(this@AuroraIme).setTitle("Choose a character").setItems(values) { _, which -> feedback(this); press(values[which]) }.show()
    true
   } }
  }
  if (text == "⌫") {
   setOnTouchListener { button, event ->
    when (event.actionMasked) {
     MotionEvent.ACTION_DOWN -> {
      stopBackspaceRepeat()
      backspaceLongPressed = false
      backspaceRepeats = 0
      button.isPressed = true
      val repeat = object : Runnable {
       override fun run() {
        backspaceLongPressed = true
        if (backspaceRepeats == 0) feedback(this@apply)
        // After the initial pause, erase repeatedly and accelerate for longer holds.
        deleteBackward(false)
        backspaceRepeats++
        backspaceHandler.postDelayed(this, if (backspaceRepeats < 12) 65L else 32L)
       }
      }
      backspaceRepeater = repeat
      backspaceHandler.postDelayed(repeat, 380L)
      true
     }
     MotionEvent.ACTION_UP -> {
      button.isPressed = false
      val wasLongPress = backspaceLongPressed
      stopBackspaceRepeat()
      if (!wasLongPress) { feedback(this@apply); deleteBackward(true) }
      true
     }
     MotionEvent.ACTION_CANCEL -> {
      button.isPressed = false
      stopBackspaceRepeat()
      true
     }
     else -> true
    }
   }
  } else setOnClickListener { action(); feedback(this) }
 }
 private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
 private fun row(keys: List<String>, weights: List<Float>? = null, inset: Int = 0) {
  val line = LinearLayout(this).apply {
   orientation = LinearLayout.HORIZONTAL
   setPadding(inset.dp, 0, inset.dp, 0)
  }
  keys.forEachIndexed { i, label ->
   val special = label in listOf("⇧", "⌫", "?123", "ABC", "#+=", "123", "🌐", "↵")
   val color = when {
    label == "↵" -> 0xff447fca.toInt()
    special -> if (store.theme() == "Light") 0xffc3d0e1.toInt() else 0xff555b66.toInt()
    else -> keyColor(i)
   }
   line.addView(key(label, weights?.get(i) ?: 1f, color) { press(label) })
  }
  root.addView(line)
 }
 private fun render() {
  stopBackspaceRepeat()
  cancelSuggestions()
  if (!::root.isInitialized) return
  root.removeAllViews(); root.setBackgroundColor(palette().first)
  suggestions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
  root.addView(suggestions, LinearLayout.LayoutParams(-1, 43.dp))
  createSuggestionBar()
  updateSuggestions()
  row((1..9).map { it.toString() } + "0")
  if (symbols) {
   if (moreSymbols) {
    row("~ ` | • √ π ÷ × ¶ ∆".split(" "))
    row(listOf("£", "€", "¥", "^", "°", "=", "{", "}", "\\", "©"))
   } else {
    row("@ # $ % & - + ( ) /".split(" "))
    row(listOf("*", "\"", ":", ";", "!", "?", "'", "_", "="))
   }
   row(listOf("#+=", "<", ">", "[", "]", "⌫"), listOf(1.5f, 1f, 1f, 1f, 1f, 1.5f))
  } else {
   row("qwertyuiop".map { it.toString() })
   row("asdfghjkl".map { it.toString() }, inset = 18)
   row(listOf("⇧") + "zxcvbnm".map { it.toString() } + "⌫", listOf(1.45f) + List(7) { 1f } + 1.45f)
  }
  row(listOf(if (symbols) "ABC" else "?123", "🌐", ",", "space", ".", "↵"), listOf(1.2f, .8f, .7f, 4.8f, .7f, 1.3f))
 }
 private fun createSuggestionBar() {
  predictionButtons.clear()
  suggestions.addView(key("▤", .54f, 0xff3b414b.toInt()) { if (!sensitive) showClipboard() })
  suggestions.addView(key("☺", .54f, 0xff3b414b.toInt()) { if (!sensitive) showEmojiPanel() })
  repeat(3) { index ->
   val button = key("", 1f, 0xff414751.toInt()) {
    val option = predictionButtons[index].text.toString()
    if (!sensitive && option.isNotBlank() && option != "Private field") {
     val typed = composing.toString()
     val chosen = if (typed.firstOrNull()?.isUpperCase() == true) option.replaceFirstChar { it.titlecase(Locale.ROOT) } else option
     val ic = currentInputConnection
     ic?.beginBatchEdit()
     if (typed.isNotEmpty()) ic?.deleteSurroundingText(typed.length, 0)
     ic?.commitText("$chosen ", 1)
     ic?.endBatchEdit()
     if (fieldLearningAllowed) { store.learn(chosen); store.learnPair(previousWord, chosen); invalidatePredictions() }
     previousWord = chosen.lowercase(Locale.ROOT)
     undoCorrection = null; composing.clear(); updateSuggestions()
    }
   }
   // Suggestions have less horizontal space than letter keys; resize text to fit.
   button.setAutoSizeTextTypeUniformWithConfiguration(9, 14, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
   button.layoutParams = LinearLayout.LayoutParams(0, 41.dp, 1f) // Full-width suggestion touch cells; spacing stays inside drawable.
   predictionButtons.add(button)
   suggestions.addView(button)
  }
  suggestions.addView(key("⚙", .54f, 0xff3b414b.toInt()) { startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) })
 }
 private fun updateSuggestions() {
  if (predictionButtons.size != 3) return
  val typed = composing.toString()
  val prefix = typed.lowercase(Locale.ROOT)
  val frequencies = predictionFrequencies ?: (if (store.learning() && !store.incognito()) store.wordMap() else emptyMap()).also { predictionFrequencies = it }
  val vocabulary = predictionVocabulary ?: ((if (store.bilingual()) english + espanol else if (spanish) espanol else english) + frequencies.keys).map { it.lowercase(Locale.ROOT) }.distinct().filter { it.isNotBlank() }.also { predictionVocabulary = it }
  val next = predictionNext ?: (if (!sensitive && !store.incognito()) store.nextWords(previousWord) else emptyMap()).also { predictionNext = it }
  val predictions = when {
   sensitive || !fieldLearningAllowed -> listOf("", if (sensitive) "Private field" else "", "")
   prefix.isBlank() -> next.entries.sortedByDescending { it.value }.map { it.key }.take(3).let { listOf(it.getOrNull(0) ?: "", it.getOrNull(1) ?: (if(spanish) "Español" else "English"), it.getOrNull(2) ?: "") }
   else -> {
    // Keep the exact typed word in the middle: corrections are suggestions, never forced.
    val completions = vocabulary.asSequence().filter { it.startsWith(prefix) && it != prefix }
     .sortedWith(compareByDescending<String> { next[it] ?: 0 }.thenByDescending { frequencies[it] ?: 0 }.thenBy { it.length }).take(3).toList()
    // One-edit typo suggestions only after three letters. Prefer actual known words.
    val corrections = if (prefix.length >= 3 && prefix.length <= 20 && !vocabulary.contains(prefix)) {
     vocabulary.asSequence().filter { kotlin.math.abs(it.length - prefix.length) <= 1 && it.firstOrNull() == prefix.firstOrNull() }
      .map { it to editDistance(prefix, it) }.filter { it.second == 1 }
      .sortedWith(compareByDescending<Pair<String, Int>> { frequencies[it.first] ?: 0 }.thenBy { it.first.length }).take(1).map { it.first }.toList()
    } else emptyList()
    val choices = (completions + corrections).distinct().filter { it != prefix }
    listOf(choices.getOrNull(0) ?: "", typed, choices.getOrNull(1) ?: "")
   }
  }
  predictions.forEachIndexed { index, option ->
   val button = predictionButtons[index]
   if (button.text.toString() != option) button.text = option
   button.isEnabled = option.isNotBlank() && option != "Private field" && option != "English" && option != "Español"
  }
 }
 private fun commitWord(allowCorrection: Boolean = false) {
  val original = composing.toString()
  if (original.isBlank()) return
  val dict = (english + espanol + store.wordMap().keys).distinct()
  val corrected = if (allowCorrection && store.autocorrect() && !sensitive && !store.incognito() && original.length >= 3 && dict.none { it.equals(original, true) }) {
   dict.asSequence().filter { it.length in (original.length - 1)..(original.length + 1) }
    .map { it to editDistance(original.lowercase(Locale.ROOT), it.lowercase(Locale.ROOT)) }
    .filter { it.second == 1 }.sortedByDescending { store.wordMap()[it.first.lowercase(Locale.ROOT)] ?: 0 }.firstOrNull()?.first ?: original
  } else original
  // Preserve the original capitalization when the correction replaces a word.
  val cased = if (corrected != original && original.firstOrNull()?.isUpperCase() == true) corrected.replaceFirstChar { it.titlecase(Locale.ROOT) } else corrected
  if (cased != original) {
   currentInputConnection?.deleteSurroundingText(original.length, 0)
   currentInputConnection?.commitText(cased, 1)
   undoCorrection = original to cased
  } else undoCorrection = null
  if (fieldLearningAllowed) { store.learn(cased); store.learnPair(previousWord, cased); invalidatePredictions() }
  previousWord = cased.lowercase(Locale.ROOT)
  predictionNext = null
  composing.clear()
 }
 private fun editDistance(a: String, b: String): Int {
  if (kotlin.math.abs(a.length - b.length) > 1) return 2
  val distance = IntArray(b.length + 1) { it }
  for (i in a.indices) {
   var previous = distance[0]; distance[0] = i + 1
   for (j in b.indices) {
    val before = distance[j+1]
    distance[j+1] = minOf(distance[j+1] + 1, distance[j] + 1, previous + if(a[i] == b[j]) 0 else 1)
    previous = before
   }
  }
  return distance[b.length]
 }
 private fun stopBackspaceRepeat() {
  backspaceRepeater?.let { backspaceHandler.removeCallbacks(it) }
  backspaceRepeater = null
 }
 override fun onFinishInput() {
  stopBackspaceRepeat(); cancelSuggestions()
  super.onFinishInput()
 }
 override fun onDestroy() {
  stopBackspaceRepeat(); cancelSuggestions()
  super.onDestroy()
 }
 private fun deleteBackward(allowUndo: Boolean) {
  val ic = currentInputConnection ?: return
  val undo = if (allowUndo) undoCorrection else null
  if (undo != null && composing.isEmpty() && ic.getTextBeforeCursor(undo.second.length + 1, 0)?.toString()?.endsWith(undo.second + " ") == true) {
   ic.deleteSurroundingText(undo.second.length + 1, 0)
   ic.commitText(undo.first, 1)
   composing.append(undo.first)
  } else {
   if (composing.isNotEmpty()) composing.deleteCharAt(composing.lastIndex)
   // deleteSurroundingTextInCodePoints handles emoji and other Unicode characters.
   if (!ic.deleteSurroundingTextInCodePoints(1, 0)) ic.deleteSurroundingText(1, 0)
  }
  undoCorrection = null
  scheduleSuggestions()
 }
 private fun press(label: String) {
  val ic = currentInputConnection ?: return
  when(label) {
   "⇧" -> { shift = !shift; render() }
   "⌫" -> deleteBackward(true)
   "space" -> {
    if (composing.isNotEmpty()) { commitWord(true); ic.commitText(" ",1) }
    else if (ic.getTextBeforeCursor(1, 0)?.toString() != " ") ic.commitText(" ",1)
    predictionNext = null; scheduleSuggestions()
   }
   "↵" -> { commitWord(); if (!ic.performEditorAction(currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE)) ic.commitText("\n",1); predictionNext = null; scheduleSuggestions() }
   "🌐" -> { commitWord(); spanish = !spanish; render() }
   "?123", "ABC", "123" -> { symbols = !symbols; moreSymbols = false; render() }
   "#+=" -> { moreSymbols = !moreSymbols; render() }
   else -> {
    val value = if (shift) label.uppercase(Locale.ROOT) else label
    val isWordCharacter = label.length == 1 && (label[0].isLetter() || label == "'")
    // Complete the previous word BEFORE punctuation enters the editor.
    if (!isWordCharacter) commitWord()
    ic.commitText(value,1)
    if (isWordCharacter) { composing.append(value); undoCorrection = null }
    if (label in listOf(".", "!", "?")) previousWord = ""
    if (!isWordCharacter) predictionNext = null
    shift = false; scheduleSuggestions()
   }
  }
 }
 private fun showEmojiPanel() {
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); setBackgroundColor(palette().first) }
  panel.addView(key("← Back to keyboard") { render() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  val sections = listOf(
   "Smileys" to listOf(
    listOf("😀","😁","😂","🤣","😊","😉","😍","😘"),
    listOf("😎","🤔","😭","😡","🙏","👏","👍","👎")
   ),
   "Useful icons" to listOf(
    listOf("✅","❌","⭐","❤️","🔥","✨","⚠️","✔️"),
    listOf("📍","📞","📅","⏰","💡","📝","💵","🔒")
   ),
   "Quick actions" to listOf(
    listOf("📎","📦","🚚","🎉","📌","➡️","⬅️","🔔")
   )
  )
  sections.forEach { (title, rows) ->
   panel.addView(TextView(this).apply {
    text = title
    setTextColor(if (store.theme() == "Light") Color.DKGRAY else Color.rgb(200,220,255))
    textSize = 12f
    setTypeface(typeface, Typeface.BOLD)
    setPadding(8.dp, 10.dp, 8.dp, 2.dp)
   })
   rows.forEach { values ->
    val line = LinearLayout(this)
    values.forEachIndexed { i, value ->
     line.addView(key(value, 1f, keyColor(i)) { currentInputConnection?.commitText(value,1); render() })
    }
    panel.addView(line)
   }
  }
  root.removeAllViews(); root.addView(panel)
 }

 private fun showClipboard() {
  val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); setBackgroundColor(palette().first) }
  panel.addView(key("← Back to keyboard") { render() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  panel.addView(key("Save current clipboard (explicit)") {
   if (!sensitive && !store.incognito()) manager.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.let { store.saveClip(it) }
   showClipboard()
  }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  if (sensitive) { render(); return }
  store.clips().forEach { clip ->
   val line = LinearLayout(this)
   line.addView(key(clip.text.take(32).replace("\n", " "), 4f) { currentInputConnection?.commitText(clip.text,1); render() })
   line.addView(key(if(clip.pinned) "★" else "☆") { store.pinClip(clip.text); showClipboard() })
   line.addView(key("×") { store.removeClip(clip.text); showClipboard() })
   panel.addView(line)
  }
  panel.addView(key("Clear clipboard history") {
   android.app.AlertDialog.Builder(this).setTitle("Clear saved clipboard?").setPositiveButton("Clear") { _, _ -> store.clearClips(); showClipboard() }.setNegativeButton("Cancel", null).show()
  }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  root.removeAllViews(); root.addView(panel)
 }
}
