plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.aurora.keyboard"
 compileSdk = 35
 defaultConfig { applicationId = "com.aurora.keyboard"; minSdk = 26; targetSdk = 35; versionCode = 9; versionName = "1.5" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
