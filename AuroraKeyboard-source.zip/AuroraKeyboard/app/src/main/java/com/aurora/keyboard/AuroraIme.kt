package com.aurora.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AuroraIme : InputMethodService() {
 private lateinit var store: Store
 private lateinit var root: LinearLayout
 private lateinit var suggestions: LinearLayout
 private var composing = StringBuilder()
 private var shift = false
 private var symbols = false
 private var spanish = false
 private var sensitive = false
 private var fieldLearningAllowed = true
 private val english = "the and you are for that with this have from your hello thanks please good morning today tomorrow minutes work can will there what when where yes no time send message later meeting home phone keyboard".split(" ")
 private val espanol = "hola gracias buenos días buenas tardes mañana hoy para como que con estoy estar tienes puedo enviar mensaje tiempo trabajo casa teléfono teclado mañana luego por favor cuando donde sí no".split(" ")
 override fun onCreate() { super.onCreate(); store = Store(this) }
 override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
  super.onStartInput(attribute, restarting)
  composing.clear()
  val variation = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
  val klass = (attribute?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
  sensitive = variation in listOf(InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD, InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) || klass == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
  fieldLearningAllowed = !sensitive && variation != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS && variation != InputType.TYPE_TEXT_VARIATION_URI
 }
 override fun onCreateInputView(): View {
  root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(3, 7, 3, 8) }
  render(); return root
 }
 private fun palette(): Pair<Int, Int> = when(store.theme()) {
  "Light" -> Color.rgb(232,237,247) to Color.rgb(255,255,255)
  "AMOLED" -> Color.BLACK to Color.rgb(31,35,43)
  "Ocean" -> Color.rgb(7,39,57) to Color.rgb(23,87,112)
  "Custom" -> Color.rgb(12,20,32) to store.customColor()
  else -> Color.rgb(12,22,38) to Color.rgb(34,65,104)
 }
 private fun keyColor(i: Int): Int {
  if (store.theme() != "Multicolor") return palette().second
  return intArrayOf(0xff164b99.toInt(), 0xff28458d.toInt(), 0xff224f68.toInt(), 0xff573479.toInt(), 0xff643363.toInt())[i % 5]
 }
 private fun bg(color: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = 12f }
 private fun key(text: String, weight: Float = 1f, color: Int = keyColor(text.hashCode().ushr(1)), action: () -> Unit): Button = Button(this).apply {
  this.text = text; textSize = if (text.length > 5) 12f else 19f; isAllCaps = false
  setTextColor(if (store.theme() == "Light") Color.BLACK else Color.WHITE)
  setPadding(0,0,0,0); minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
  background = bg(color); layoutParams = LinearLayout.LayoutParams(0, 46.dp, weight).apply { setMargins(2,3,2,3) }
  setOnClickListener { action() }
 }
 private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
 private fun row(keys: List<String>, weights: List<Float>? = null) {
  val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
  keys.forEachIndexed { i, label -> line.addView(key(label, weights?.get(i) ?: 1f, if (label == "↵") 0xff266ce6.toInt() else keyColor(i)) { press(label) }) }
  root.addView(line)
 }
 private fun render() {
  if (!::root.isInitialized) return
  root.removeAllViews(); root.setBackgroundColor(palette().first)
  suggestions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
  root.addView(suggestions, LinearLayout.LayoutParams(-1, 42.dp))
  updateSuggestions()
  row((1..9).map { it.toString() } + "0")
  if (symbols) {
   row("@ # $ % & - + ( ) /".split(" "))
   row("* \" : ; ! ? '".split(" "))
   row(listOf("ABC", "_", "=", "<", ">", "⌫"))
  } else {
   row("qwertyuiop".map { it.toString() })
   row("asdfghjkl".map { it.toString() })
   row(listOf("⇧") + "zxcvbnm".map { it.toString() } + "⌫")
  }
  row(listOf(if (symbols) "ABC" else "?123", "🌐", ",", "space", ".", "↵"), listOf(1.15f, .85f, .6f, 3.5f, .6f, 1.1f))
 }
 private fun updateSuggestions() {
  if (!::suggestions.isInitialized) return
  suggestions.removeAllViews()
  val clipboard = key("▤", .48f, 0xff1c3656.toInt()) { showClipboard() }
  suggestions.addView(clipboard)
  val prefix = composing.toString().lowercase(Locale.ROOT)
  val dict = (if (spanish) espanol else english) + store.wordMap().keys
  val predictions = if (sensitive || prefix.isBlank()) listOf("Aurora", "AI", if(spanish) "Español" else "English") else dict.asSequence().filter { it.startsWith(prefix) && it != prefix }.distinct().sortedByDescending { store.wordMap()[it] ?: 0 }.take(3).toList().ifEmpty { listOf(prefix) }
  predictions.forEach { option -> suggestions.addView(key(option, 1f, 0xff203551.toInt()) {
   if (!sensitive && prefix.isNotBlank()) {
    currentInputConnection?.deleteSurroundingText(composing.length, 0)
    currentInputConnection?.commitText("$option ", 1)
    if (fieldLearningAllowed) store.learn(option)
    composing.clear(); updateSuggestions()
   }
  }) }
  suggestions.addView(key("⚙", .48f, 0xff1c3656.toInt()) { startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) })
 }
 private fun commitWord() {
  if (fieldLearningAllowed) store.learn(composing.toString())
  composing.clear()
 }
 private fun press(label: String) {
  val ic = currentInputConnection ?: return
  when(label) {
   "⇧" -> { shift = !shift; render() }
   "⌫" -> { if (composing.isNotEmpty()) composing.deleteCharAt(composing.lastIndex); ic.deleteSurroundingText(1,0); updateSuggestions() }
   "space" -> { commitWord(); ic.commitText(" ",1); updateSuggestions() }
   "↵" -> { commitWord(); if (!ic.performEditorAction(currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE)) ic.commitText("\n",1); updateSuggestions() }
   "🌐" -> { commitWord(); spanish = !spanish; render() }
   "?123", "ABC" -> { symbols = !symbols; render() }
   else -> {
    val value = if (shift) label.uppercase(Locale.ROOT) else label
    ic.commitText(value,1)
    if (label.length == 1 && (label[0].isLetter() || label == "'")) composing.append(value)
    else commitWord()
    shift = false; updateSuggestions()
   }
  }
 }
 private fun showClipboard() {
  val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); setBackgroundColor(palette().first) }
  panel.addView(key("← Back to keyboard") { render() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  panel.addView(key("Save current clipboard (explicit)") {
   if (!sensitive && !store.incognito()) manager.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.let { store.saveClip(it) }
   showClipboard()
  }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  store.clips().forEach { clip ->
   val line = LinearLayout(this)
   line.addView(key(clip.text.take(32).replace("\n", " "), 4f) { currentInputConnection?.commitText(clip.text,1); render() })
   line.addView(key(if(clip.pinned) "★" else "☆") { store.pinClip(clip.text); showClipboard() })
   panel.addView(line)
  }
  panel.addView(key("Clear clipboard history") { store.clearClips(); showClipboard() }.apply { layoutParams = LinearLayout.LayoutParams(-1,44.dp) })
  root.removeAllViews(); root.addView(panel)
 }
}
