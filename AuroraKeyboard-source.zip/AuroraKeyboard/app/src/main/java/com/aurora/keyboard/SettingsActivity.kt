package com.aurora.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
 private lateinit var store: Store
 private lateinit var panel: LinearLayout
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); store = Store(this); render() }
 private fun button(text: String, action: () -> Unit) {
  panel.addView(Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); background = GradientDrawable().apply { setColor(0xff244c82.toInt()); cornerRadius = 22f }; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, 52.dp).apply { bottomMargin = 9.dp })
 }
 private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
 private fun heading(text: String) { panel.addView(TextView(this).apply { this.text = text; textSize = 19f; setTextColor(Color.WHITE); setPadding(0,14.dp,0,12.dp) }) }
 private fun toggle(label: String, initial: Boolean, changed: (Boolean) -> Unit) {
  panel.addView(Switch(this).apply { text = label; isChecked = initial; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, value -> changed(value) } })
 }
 private fun render() {
  panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22.dp,24.dp,22.dp,24.dp); setBackgroundColor(0xff0c1626.toInt()) }
  val scroll = android.widget.ScrollView(this).apply { addView(panel) }; setContentView(scroll)
  heading("Aurora AI Keyboard • Setup")
  button("1. Enable Aurora in Android keyboards") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
  button("2. Select Aurora as keyboard") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
  heading("Keyboard theme")
  listOf("Multicolor", "Light", "AMOLED", "Ocean", "Custom").forEach { name -> button((if(store.theme()==name) "✓ " else "") + name) { store.setTheme(name); render() } }
  heading("Custom key color")
  val colorField = EditText(this).apply { hint = "#344C78"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT; setText(String.format("#%06X", store.customColor() and 0xffffff)) }
  panel.addView(colorField)
  button("Apply custom color") {
   try { store.setCustomColor(Color.parseColor(colorField.text.toString())); store.setTheme("Custom"); render() }
   catch (_: IllegalArgumentException) { Toast.makeText(this, "Enter a color like #344C78", Toast.LENGTH_SHORT).show() }
  }
  heading("Learning & privacy")
  toggle("Learn frequently used words", store.learning()) { store.setLearning(it) }
  toggle("Incognito: pause learning and clipboard saves", store.incognito()) { store.setIncognito(it) }
  button("Delete learned vocabulary") { android.app.AlertDialog.Builder(this).setTitle("Delete learned words?").setPositiveButton("Delete") { _, _ -> store.clearWords(); Toast.makeText(this,"Vocabulary cleared",Toast.LENGTH_SHORT).show() }.setNegativeButton("Cancel", null).show() }
  button("Delete clipboard history") { android.app.AlertDialog.Builder(this).setTitle("Delete clipboard history?").setPositiveButton("Delete") { _, _ -> store.clearClips() }.setNegativeButton("Cancel", null).show() }
  heading("English + Español • globe key switches languages")
  heading("Privacy: offline only. No internet permission. Clipboard history saves only when you tap Save inside the keyboard; unpinned clips expire after 24 hours. No passwords are learned.")
 }
}
